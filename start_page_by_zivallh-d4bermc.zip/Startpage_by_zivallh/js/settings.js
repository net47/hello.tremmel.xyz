
$(document).ready(function() {

/**
	Simple configuration using (mostly) true/false settings. Use "true" to enable
	feature, "false" to disable feature.
*/

	// Open in new window_tab
	newwindow = true;

	// Enable/disable various search engines
	google = true;
	yahoo = false;
	wikipedia = false;
	flickr = false;
	deviantart = false;

	// Focus on searchbox when opening
	focusSearch = false;

	// Enable clock
	showClock = true;
	
	// Enable date
	showDate = true;
});
